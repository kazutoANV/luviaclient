package dev.luvia;

import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;

public class Modules {
    static final Minecraft mc = Minecraft.getMinecraft();

    public static class Fps extends Module {
        public Fps(){super("FPS","HUD",6,6);}
        public void render(){Gfx.hud(x,y,Minecraft.getDebugFPS()+" FPS");}
    }

    public static class Cps extends Module {
        List<Long> l=new ArrayList<Long>(), r=new ArrayList<Long>(); boolean pl,pr;
        public Cps(){super("CPS","HUD",6,26);}
        int c(List<Long>a){long n=System.currentTimeMillis(); Iterator<Long> it=a.iterator(); while(it.hasNext()) if(n-it.next()>1000)it.remove(); return a.size();}
        public void render(){
            boolean bl=Mouse.isButtonDown(0),br=Mouse.isButtonDown(1);
            if(bl&&!pl)l.add(System.currentTimeMillis()); if(br&&!pr)r.add(System.currentTimeMillis());
            pl=bl;pr=br; Gfx.hud(x,y,c(l)+" | "+c(r)+" CPS");
        }
    }

    public static class Coords extends Module {
        public Coords(){super("Coordinates","HUD",6,46);}
        public void render(){Gfx.hud(x,y,String.format("XYZ %.0f %.0f %.0f",mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ));}
    }

    public static class Keys extends Module {
        public Keys(){super("Keystrokes","HUD",6,70);}
        void key(int kx,int ky,int w,String s,boolean d){Gfx.rrect(kx,ky,w,20,4,d?Theme.accent2():0x90140F24);Gfx.center(s,kx+w/2,ky+6,0xFFFFFFFF);}
        public void render(){
            key(x+23,y,20,"W",mc.gameSettings.keyBindForward.isKeyDown());
            key(x,y+22,20,"A",mc.gameSettings.keyBindLeft.isKeyDown());
            key(x+23,y+22,20,"S",mc.gameSettings.keyBindBack.isKeyDown());
            key(x+46,y+22,20,"D",mc.gameSettings.keyBindRight.isKeyDown());
            key(x,y+44,32,"LMB",Mouse.isButtonDown(0));key(x+34,y+44,32,"RMB",Mouse.isButtonDown(1));
        }
    }

    public static class Armor extends Module {
        public Armor(){super("Armor Status","HUD",6,140);}
        public void render(){
            RenderHelper.enableGUIStandardItemLighting();
            for(int i=0;i<4;i++){ItemStack s=mc.thePlayer.inventory.armorInventory[3-i];if(s==null)continue;
                mc.getRenderItem().renderItemAndEffectIntoGUI(s,x,y+i*18);
                Gfx.text(""+(s.getMaxDamage()-s.getItemDamage()),x+20,y+i*18+4,0xFFFFFFFF);}
            RenderHelper.disableStandardItemLighting();
        }
    }

    public static class Health extends Module {
        public Health(){super("Health","HUD",6,160);}
        public void render(){Gfx.hud(x,y,String.format("HP %.1f / %.1f",mc.thePlayer.getHealth(),mc.thePlayer.getMaxHealth()));}
    }

    public static class Food extends Module {
        public Food(){super("Food","HUD",6,180);}
        public void render(){Gfx.hud(x,y,"Food "+mc.thePlayer.getFoodStats().getFoodLevel());}
    }

    public static class Ping extends Module {
        public Ping(){super("Ping","HUD",6,200);}
        public void render(){
            int p=-1; try{NetworkPlayerInfo i=mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());if(i!=null)p=i.getResponseTime();}catch(Exception ignored){}
            Gfx.hud(x,y,"Ping "+p+" ms");
        }
    }

    public static class Speed extends Module {
        public Speed(){super("Speed","HUD",6,220);}
        public void render(){
            double dx=mc.thePlayer.posX-mc.thePlayer.prevPosX, dz=mc.thePlayer.posZ-mc.thePlayer.prevPosZ;
            double bps=Math.sqrt(dx*dx+dz*dz)*20;
            Gfx.hud(x,y,String.format("Speed %.2f b/s",bps));
        }
    }

    public static class Direction extends Module {
        public Direction(){super("Direction","HUD",6,240);}
        public void render(){
            String[] d={"S","SW","W","NW","N","NE","E","SE"};
            int i=(int)Math.floor((mc.thePlayer.rotationYaw*8.0/360.0)+0.5)&7;
            Gfx.hud(x,y,d[i]);
        }
    }

    public static class ArrayListHud extends Module {
        public ArrayListHud(){super("ArrayList","HUD",0,0);}
        public void render(){
            int y0=6;
            List<Module> active=new ArrayList<Module>();
            for(Module m:Luvia.modules)if(m.on&&m!=this)active.add(m);
            Collections.sort(active,new Comparator<Module>(){public int compare(Module a,Module b){return Gfx.width(b.name)-Gfx.width(a.name);}});
            for(Module m:active){int w=Gfx.width(m.name)+14;Gfx.rrect(mc.displayWidth/Math.max(1,new net.minecraft.client.gui.ScaledResolution(mc).getScaleFactor())-w-6,y0,w,18,4,0xB0140F24);Gfx.text(m.name,mc.displayWidth/Math.max(1,new net.minecraft.client.gui.ScaledResolution(mc).getScaleFactor())-w+1,y0+5,Theme.accent());y0+=20;}
        }
    }

    public static class ToggleSprint extends Module {
        public ToggleSprint(){super("Toggle Sprint","Player",6,220);}
        public void tick(){if(mc.thePlayer!=null&&mc.gameSettings.keyBindForward.isKeyDown()&&!mc.thePlayer.isSneaking()&&!mc.thePlayer.isCollidedHorizontally)mc.thePlayer.setSprinting(true);}
        public void render(){Gfx.hud(x,mc.displayHeight/2-20,"Sprinting");}
    }

    public static class SprintIndicator extends Module {
        public SprintIndicator(){super("Sprint Indicator","Player",6,242);}
        public void render(){if(mc.thePlayer.isSprinting())Gfx.hud(x,y,"SPRINT");}
    }

    public static class PotionHud extends Module {
        public PotionHud(){super("Potion HUD","Player",6,264);}
        public void render(){
            int yy=y;
            for(Object o:mc.thePlayer.getActivePotionEffects()){
                PotionEffect p=(PotionEffect)o;
                String s=p.getEffectName().replace("potion.","")+" "+(p.getDuration()/20)+"s";
                Gfx.hud(x,yy,s); yy+=18;
            }
        }
    }

    public static class KeystrokesBig extends Module {
        public KeystrokesBig(){super("Large Keystrokes","Player",6,286);}
        void k(int xx,int yy,String s,boolean a){Gfx.rrect(xx,yy,28,28,5,a?Theme.accent2():0xA0140F24);Gfx.center(s,xx+14,yy+9,0xFFFFFFFF);}
        public void render(){k(x+30,y,"W",mc.gameSettings.keyBindForward.isKeyDown());k(x,y+30,"A",mc.gameSettings.keyBindLeft.isKeyDown());k(x+30,y+30,"S",mc.gameSettings.keyBindBack.isKeyDown());k(x+60,y+30,"D",mc.gameSettings.keyBindRight.isKeyDown());}
    }

    public static class ItemInfo extends Module {
        public ItemInfo(){super("Held Item","Player",6,320);}
        public void render(){ItemStack s=mc.thePlayer.getHeldItem();if(s!=null)Gfx.hud(x,y,s.getDisplayName());}
    }

    public static class Fullbright extends Module {
        float old;
        public Fullbright(){super("Fullbright","Render",0,0);}
        public void onEnable(){old=mc.gameSettings.gammaSetting;mc.gameSettings.gammaSetting=100f;}
        public void onDisable(){mc.gameSettings.gammaSetting=old;}
    }

    public static class Zoom extends Module {
        public Zoom(){super("Zoom (C)","Render",0,0);}
        public boolean active(){return on&&mc.currentScreen==null&&Keyboard.isKeyDown(Keyboard.KEY_C);}
    }

    public static class MotionBlur extends Module {
        private int[] tex=new int[]{-1,-1};
        private int write=0;
        private int lastW=-1,lastH=-1;
        private boolean ready=false;

        public MotionBlur(){super("Motion Blur","Render",0,0);}

        private void setup(int w,int h){
            if(tex[0]!=-1){GL11.glDeleteTextures(tex[0]);GL11.glDeleteTextures(tex[1]);}
            tex[0]=GL11.glGenTextures();tex[1]=GL11.glGenTextures();
            for(int t:tex){
                GL11.glBindTexture(GL11.GL_TEXTURE_2D,t);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_MIN_FILTER,GL11.GL_LINEAR);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_MAG_FILTER,GL11.GL_LINEAR);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_WRAP_S,GL12.GL_CLAMP_TO_EDGE);
                GL11.glTexParameteri(GL11.GL_TEXTURE_2D,GL11.GL_TEXTURE_WRAP_T,GL12.GL_CLAMP_TO_EDGE);
                GL11.glTexImage2D(GL11.GL_TEXTURE_2D,0,GL11.GL_RGBA,w,h,0,GL11.GL_RGBA,GL11.GL_UNSIGNED_BYTE,(java.nio.ByteBuffer)null);
            }
            GL11.glBindTexture(GL11.GL_TEXTURE_2D,0);
            lastW=w;lastH=h;ready=false;write=0;
        }

        public void renderBlur(){
            if(mc.currentScreen!=null)return;
            int w=mc.displayWidth,h=mc.displayHeight;
            if(w<=0||h<=0)return;
            if(!ready||w!=lastW||h!=lastH)setup(w,h);

            int writeTex=tex[write],readTex=tex[1-write];
            GL11.glBindTexture(GL11.GL_TEXTURE_2D,writeTex);
            GL11.glCopyTexSubImage2D(GL11.GL_TEXTURE_2D,0,0,0,0,0,w,h);

            if(ready){
                GlStateManager.pushMatrix();
                GlStateManager.enableBlend();
                GlStateManager.disableDepth();
                GlStateManager.enableTexture2D();
                GlStateManager.color(1f,1f,1f,0.18f);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D,readTex);
                GL11.glBegin(GL11.GL_QUADS);
                GL11.glTexCoord2f(0,1);GL11.glVertex2f(0,0);
                GL11.glTexCoord2f(1,1);GL11.glVertex2f(mc.displayWidth,0);
                GL11.glTexCoord2f(1,0);GL11.glVertex2f(mc.displayWidth,mc.displayHeight);
                GL11.glTexCoord2f(0,0);GL11.glVertex2f(0,mc.displayHeight);
                GL11.glEnd();
                GL11.glBindTexture(GL11.GL_TEXTURE_2D,0);
                GlStateManager.color(1,1,1,1);
                GlStateManager.enableDepth();
                GlStateManager.disableBlend();
                GlStateManager.popMatrix();
            }
            write=1-write;ready=true;
        }

        public void onDisable(){ready=false;}
    }

    public static class Crosshair extends Module {
        public Crosshair(){super("Custom Crosshair","Render",0,0);}
        public void render(){
            net.minecraft.client.gui.ScaledResolution s=new net.minecraft.client.gui.ScaledResolution(mc);
            int cx=s.getScaledWidth()/2,cy=s.getScaledHeight()/2;
            Gui.drawRect(cx-1,cy-7,cx+2,cy-2,Theme.accent());
            Gui.drawRect(cx-1,cy+2,cx+2,cy+7,Theme.accent());
            Gui.drawRect(cx-7,cy-1,cx-2,cy+2,Theme.accent());
            Gui.drawRect(cx+2,cy-1,cx+7,cy+2,Theme.accent());
        }
    }

    public static class TimeChanger extends Module {
        long old;
        public TimeChanger(){super("Time Changer","Render",0,0);}
        public void tick(){if(mc.theWorld!=null)mc.theWorld.setWorldTime(6000L);}
        public void onDisable(){if(mc.theWorld!=null)mc.theWorld.setWorldTime(old);}
        public void onEnable(){if(mc.theWorld!=null)old=mc.theWorld.getWorldTime();}
    }

    public static class NoBob extends Module {
        public NoBob(){super("No View Bob","Render",0,0);}
        public void tick(){if(mc.gameSettings.viewBobbing)mc.gameSettings.viewBobbing=false;}
        public void onDisable(){mc.gameSettings.viewBobbing=true;}
    }

    public static class ThirdPerson extends Module {
        public ThirdPerson(){super("Third Person","Render",0,0);}
        public void onEnable(){mc.gameSettings.thirdPersonView=1;}
        public void onDisable(){mc.gameSettings.thirdPersonView=0;}
    }

    public static class FPSBoostVisual extends Module {
        public FPSBoostVisual(){super("FPS Boost","Render",0,0);}
        public void onEnable(){mc.gameSettings.particleSetting=2;mc.gameSettings.entityShadows=false;mc.gameSettings.clouds=false;}
        public void onDisable(){mc.gameSettings.particleSetting=0;mc.gameSettings.entityShadows=true;mc.gameSettings.clouds=true;}
    }

    public static class AutoGG extends Module {
        boolean sent=false;
        public AutoGG(){super("Auto GG","Utility",0,0);MinecraftForge.EVENT_BUS.register(this);}
        @SubscribeEvent public void chat(ClientChatReceivedEvent e){
            if(!on||sent)return;
            String s=e.message.getUnformattedText().toLowerCase();
            if(s.contains("victory")||s.contains("won the game")||s.contains("winner")){
                mc.thePlayer.sendChatMessage("gg");sent=true;
            }
        }
        public void tick(){if(mc.thePlayer!=null&&mc.thePlayer.ticksExisted%100==0)sent=false;}
    }

    public static class ReachDisplay extends Module {
        double last=0;
        public ReachDisplay(){super("Reach Display","PvP",6,6);}
        public void render(){if(last>0)Gfx.hud(x,y,String.format("Reach %.2f",last));}
    }

    public static class ComboCounter extends Module {
        int combo=0;long last=0;
        public ComboCounter(){super("Combo Counter","PvP",6,26);}
        public void tick(){if(mc.thePlayer!=null&&mc.thePlayer.hurtTime>0&&System.currentTimeMillis()-last>120){combo++;last=System.currentTimeMillis();}if(System.currentTimeMillis()-last>1000)combo=0;}
        public void render(){if(combo>0)Gfx.hud(x,y,"Combo x"+combo);}
    }

    public static class HitColor extends Module {
        public HitColor(){super("Hit Effect","PvP",6,46);}
        public void render(){if(mc.thePlayer.hurtTime>0){int s=Gfx.sr().getScaledWidth(),h=Gfx.sr().getScaledHeight();Gui.drawRect(0,0,s,2,0xAAFF3B6B);Gui.drawRect(0,h-2,s,h,0xAAFF3B6B);}}
    }

    public static class TargetInfo extends Module {
        public TargetInfo(){super("Target Info","PvP",6,66);}
        public void render(){
            if(mc.objectMouseOver!=null&&mc.objectMouseOver.entityHit!=null){
                net.minecraft.entity.Entity e=mc.objectMouseOver.entityHit;
                Gfx.hud(x,y,e.getName()+"  "+String.format("%.1f",e.getDistanceToEntity(mc.thePlayer)));
            }
        }
    }

    public static class SessionInfo extends Module {
        long start=System.currentTimeMillis();
        public SessionInfo(){super("Session Info","Utility",6,6);}
        public void render(){long sec=(System.currentTimeMillis()-start)/1000;Gfx.hud(x,y,String.format("Session %02d:%02d",sec/60,sec%60));}
    }


    // ===== Luvia 2.1 HUD / Visual / Utility expansion =====
    public static class FPSGraph extends Module {
        final int[] samples=new int[60]; int idx=0;
        public FPSGraph(){super("FPS Graph","HUD",6,360);}
        public void render(){
            samples[idx++%samples.length]=Minecraft.getDebugFPS();
            int base=y+48; Gfx.rrect(x,y,132,52,6,0xA0140F24);
            Gfx.text("FPS Graph",x+7,y+5,Theme.accent());
            for(int i=1;i<samples.length;i++){
                int a=samples[(idx-i-1+samples.length)%samples.length],b=samples[(idx-i+samples.length)%samples.length];
                int ya=base-Math.min(34,a/3),yb=base-Math.min(34,b/3);
                Gfx.line(x+7+i*2,yb,x+7+(i-1)*2,ya, Theme.accent());
            }
        }
    }
    public static class Clock extends Module {
        public Clock(){super("Clock","HUD",150,6);}
        public void render(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("HH:mm:ss");Gfx.hud(x,y,f.format(new Date()));}
    }
    public static class WorldTime extends Module {
        public WorldTime(){super("World Time","HUD",150,26);}
        public void render(){if(mc.theWorld!=null)Gfx.hud(x,y,"World "+(mc.theWorld.getWorldTime()%24000));}
    }
    public static class Biome extends Module {
        public Biome(){super("Biome","HUD",150,46);}
        public void render(){if(mc.theWorld!=null&&mc.thePlayer!=null)Gfx.hud(x,y,mc.theWorld.getBiomeGenForCoords(new BlockPos(mc.thePlayer)).biomeName);}
    }
    public static class Velocity extends Module {
        public Velocity(){super("Velocity","HUD",150,66);}
        public void render(){if(mc.thePlayer!=null){double v=Math.sqrt(mc.thePlayer.motionX*mc.thePlayer.motionX+mc.thePlayer.motionZ*mc.thePlayer.motionZ)*100;Gfx.hud(x,y,String.format("Velocity %.1f",v));}}
    }
    public static class JumpCounter extends Module {
        int jumps=0; boolean last=false;
        public JumpCounter(){super("Jump Counter","HUD",150,86);}
        public void tick(){boolean b=mc.gameSettings.keyBindJump.isKeyDown();if(b&&!last)jumps++;last=b;}
        public void render(){Gfx.hud(x,y,"Jumps "+jumps);}
    }
    public static class AirTime extends Module {
        int air=0;
        public AirTime(){super("Air Time","HUD",150,106);}
        public void tick(){if(mc.thePlayer!=null)air=mc.thePlayer.onGround?0:air+1;}
        public void render(){Gfx.hud(x,y,"Air "+air+"t");}
    }
    public static class Facing extends Module {
        public Facing(){super("Facing","HUD",150,126);}
        public void render(){if(mc.thePlayer!=null)Gfx.hud(x,y,"Facing "+EnumFacing.getHorizontal(MathHelper.floor_double(mc.thePlayer.rotationYaw*4/360+0.5)&3).getName());}
    }
    public static class ChunkCoords extends Module {
        public ChunkCoords(){super("Chunk Coords","HUD",150,146);}
        public void render(){if(mc.thePlayer!=null)Gfx.hud(x,y,"Chunk "+(MathHelper.floor_double(mc.thePlayer.posX)>>4)+", "+(MathHelper.floor_double(mc.thePlayer.posZ)>>4));}
    }
    public static class LightLevel extends Module {
        public LightLevel(){super("Light Level","HUD",150,166);}
        public void render(){if(mc.theWorld!=null&&mc.thePlayer!=null)Gfx.hud(x,y,"Light "+mc.theWorld.getLight(new BlockPos(mc.thePlayer)));}
    }
    public static class EntityCount extends Module {
        public EntityCount(){super("Entity Count","HUD",150,186);}
        public void render(){if(mc.theWorld!=null)Gfx.hud(x,y,"Entities "+mc.theWorld.loadedEntityList.size());}
    }
    public static class Durability extends Module {
        public Durability(){super("Held Durability","HUD",150,206);}
        public void render(){ItemStack s=mc.thePlayer.getHeldItem();if(s!=null&&s.isItemStackDamageable())Gfx.hud(x,y,"Durability "+(s.getMaxDamage()-s.getItemDamage()));}
    }
    public static class PotionList extends Module {
        public PotionList(){super("Potion List","HUD",150,226);}
        public void render(){int yy=y;for(Object o:mc.thePlayer.getActivePotionEffects()){PotionEffect p=(PotionEffect)o;Gfx.hud(x,yy,p.getEffectName().replace("potion.","")+" "+(p.getDuration()/20));yy+=18;}}
    }
    public static class FPSLimit extends Module {
        int old;
        public FPSLimit(){super("FPS Limit 60","Render",0,0);}
        public void onEnable(){old=mc.gameSettings.limitFramerate;mc.gameSettings.limitFramerate=60;}
        public void onDisable(){mc.gameSettings.limitFramerate=old;}
    }
    public static class SmoothCamera extends Module {
        boolean old;
        public SmoothCamera(){super("Smooth Camera","Render",0,0);}
        public void onEnable(){old=mc.gameSettings.smoothCamera;mc.gameSettings.smoothCamera=true;}
        public void onDisable(){mc.gameSettings.smoothCamera=old;}
    }
    public static class NoWeather extends Module {
        public NoWeather(){super("No Weather","Render",0,0);}
        public void tick(){if(mc.theWorld!=null){mc.theWorld.setRainStrength(0);mc.theWorld.setThunderStrength(0);}}
    }
    public static class NoParticles extends Module {
        int old;
        public NoParticles(){super("No Particles","Render",0,0);}
        public void onEnable(){old=mc.gameSettings.particleSetting;mc.gameSettings.particleSetting=2;}
        public void onDisable(){mc.gameSettings.particleSetting=old;}
    }
    public static class NoClouds extends Module {
        boolean old;
        public NoClouds(){super("No Clouds","Render",0,0);}
        public void onEnable(){old=mc.gameSettings.clouds;mc.gameSettings.clouds=false;}
        public void onDisable(){mc.gameSettings.clouds=old;}
    }
    public static class LowGraphics extends Module {
        int old;
        public LowGraphics(){super("Low Graphics","Render",0,0);}
        public void onEnable(){old=mc.gameSettings.fancyGraphics?1:0;mc.gameSettings.fancyGraphics=false;mc.gameSettings.ambientOcclusion=0;}
        public void onDisable(){mc.gameSettings.fancyGraphics=old==1;mc.gameSettings.ambientOcclusion=2;}
    }
    public static class FastRender extends Module {
        int old;
        public FastRender(){super("Fast Render","Render",0,0);}
        public void onEnable(){old=mc.gameSettings.renderDistanceChunks;mc.gameSettings.renderDistanceChunks=Math.min(old,6);}
        public void onDisable(){mc.gameSettings.renderDistanceChunks=old;}
    }
    public static class HideHand extends Module {
        public HideHand(){super("Hide Hand","Render",0,0);}
        public void tick(){mc.gameSettings.hideGUI=mc.gameSettings.hideGUI;}
    }
    public static class CleanParticles extends Module {
        public CleanParticles(){super("Clean Particles","Render",0,0);}
        public void onEnable(){mc.gameSettings.particleSetting=2;}
    }
    public static class CrosshairDot extends Module {
        public CrosshairDot(){super("Crosshair Dot","Render",0,0);}
        public void render(){int cx=Gfx.sr().getScaledWidth()/2,cy=Gfx.sr().getScaledHeight()/2;Gui.drawRect(cx-1,cy-1,cx+2,cy+2,Theme.accent());}
    }
    public static class HitMarker extends Module {
        public HitMarker(){super("Hit Marker","PvP",6,86);}
        public void render(){if(mc.thePlayer!=null&&mc.thePlayer.hurtTime>0){int cx=Gfx.sr().getScaledWidth()/2,cy=Gfx.sr().getScaledHeight()/2;Gfx.line(cx-7,cy-7,cx-2,cy-2,Theme.accent());Gfx.line(cx+2,cy-2,cx+7,cy-7,Theme.accent());Gfx.line(cx-7,cy+7,cx-2,cy+2,Theme.accent());Gfx.line(cx+2,cy+2,cx+7,cy+7,Theme.accent());}}
    }
    public static class CombatStatus extends Module {
        public CombatStatus(){super("Combat Status","PvP",6,106);}
        public void render(){if(mc.thePlayer!=null)Gfx.hud(x,y,"Combat "+(mc.thePlayer.hurtTime>0?"HIT":"READY"));}
    }
    public static class TargetDistance extends Module {
        public TargetDistance(){super("Target Distance","PvP",6,126);}
        public void render(){if(mc.objectMouseOver!=null&&mc.objectMouseOver.entityHit!=null)Gfx.hud(x,y,String.format("Distance %.2f",mc.thePlayer.getDistanceToEntity(mc.objectMouseOver.entityHit)));}
    }
    public static class AttackIndicator extends Module {
        public AttackIndicator(){super("Attack Indicator","PvP",6,146);}
        public void render(){float p=mc.thePlayer.getCooledAttackStrength(0);int w=80;Gfx.rrect(x,y,w,8,3,0xA0140F24);Gfx.rrect(x,y,(int)(w*p),8,3,Theme.accent());}
    }
    public static class FPSColor extends Module {
        public FPSColor(){super("FPS Color","Utility",0,0);}
        public void render(){int fps=Minecraft.getDebugFPS();Gfx.hud(x,y,"FPS Color "+(fps>=120?"HIGH":fps>=60?"GOOD":"LOW"));}
    }
    public static class ServerInfo extends Module {
        public ServerInfo(){super("Server Info","Utility",150,6);}
        public void render(){String s=mc.getCurrentServerData()==null?"Singleplayer":mc.getCurrentServerData().serverIP;Gfx.hud(x,y,s);}
    }
    public static class MemoryInfo extends Module {
        public MemoryInfo(){super("Memory","Utility",150,26);}
        public void render(){Runtime r=Runtime.getRuntime();long used=(r.totalMemory()-r.freeMemory())/1048576;Gfx.hud(x,y,"RAM "+used+"MB");}
    }
    public static class CoordinatesCopyHint extends Module {
        public CoordinatesCopyHint(){super("Coords Hint","Utility",150,46);}
        public void render(){if(mc.thePlayer!=null)Gfx.hud(x,y,"XYZ ready");}
    }
    public static class AutoRespawn extends Module {
        public AutoRespawn(){super("Auto Respawn","Utility",0,0);}
        public void tick(){if(mc.thePlayer!=null&&mc.thePlayer.isDead)mc.thePlayer.respawnPlayer();}
    }
    public static class ClearEffects extends Module {
        public ClearEffects(){super("Clear Effects","Utility",0,0);}
        public void onEnable(){if(mc.thePlayer!=null)mc.thePlayer.clearActivePotions();}
    }
    public static class HideGUI extends Module {
        boolean old;
        public HideGUI(){super("Hide GUI","Utility",0,0);}
        public void onEnable(){old=mc.gameSettings.hideGUI;mc.gameSettings.hideGUI=true;}
        public void onDisable(){mc.gameSettings.hideGUI=old;}
    }


    // ===== Luvia 2.2 utility/visual modules =====
    public static class Saturation extends Module { public Saturation(){super("Saturation","HUD",6,500);} public void render(){Gfx.hud(x,y,"Saturation "+mc.thePlayer.getFoodStats().getSaturationLevel());} }
    public static class Experience extends Module { public Experience(){super("Experience","HUD",6,520);} public void render(){Gfx.hud(x,y,String.format("XP %d | %.0f%%",mc.thePlayer.experienceTotal,mc.thePlayer.experience*100f));} }
    public static class Level extends Module { public Level(){super("Level","HUD",6,540);} public void render(){Gfx.hud(x,y,"Level "+mc.thePlayer.experienceLevel); } }
    public static class Position extends Module { public Position(){super("Position","HUD",6,560);} public void render(){Gfx.hud(x,y,String.format("X %.1f  Y %.1f  Z %.1f",mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ));} }
    public static class MotionX extends Module { public MotionX(){super("Motion X","HUD",6,580);} public void render(){Gfx.hud(x,y,String.format("Motion X %.3f",mc.thePlayer.motionX));} }
    public static class MotionY extends Module { public MotionY(){super("Motion Y","HUD",6,600);} public void render(){Gfx.hud(x,y,String.format("Motion Y %.3f",mc.thePlayer.motionY));} }
    public static class MotionZ extends Module { public MotionZ(){super("Motion Z","HUD",6,620);} public void render(){Gfx.hud(x,y,String.format("Motion Z %.3f",mc.thePlayer.motionZ));} }
    public static class Rotation extends Module { public Rotation(){super("Rotation","HUD",6,640);} public void render(){Gfx.hud(x,y,String.format("Yaw %.1f",mc.thePlayer.rotationYaw));} }
    public static class Pitch extends Module { public Pitch(){super("Pitch","HUD",6,660);} public void render(){Gfx.hud(x,y,String.format("Pitch %.1f",mc.thePlayer.rotationPitch));} }
    public static class BlockUnder extends Module { public BlockUnder(){super("Block Under","HUD",6,680);} public void render(){net.minecraft.util.BlockPos p=new net.minecraft.util.BlockPos(mc.thePlayer.posX,mc.thePlayer.posY-1,mc.thePlayer.posZ);Gfx.hud(x,y,mc.theWorld.getBlockState(p).getBlock().getLocalizedName());} }
    public static class BiomeCoords extends Module { public BiomeCoords(){super("Biome Coords","HUD",6,700);} public void render(){net.minecraft.util.BlockPos p=new net.minecraft.util.BlockPos(mc.thePlayer);Gfx.hud(x,y,mc.theWorld.getBiomeGenForCoords(p).biomeName); } }
    public static class FallDistance extends Module { public FallDistance(){super("Fall Distance","HUD",6,720);} public void render(){Gfx.hud(x,y,String.format("Fall %.1f",mc.thePlayer.fallDistance));} }
    public static class JumpHeight extends Module { public JumpHeight(){super("Jump Height","HUD",6,740);} public void render(){Gfx.hud(x,y,String.format("Jump Y %.3f",mc.thePlayer.motionY));} }
    public static class DistanceWalked extends Module { public DistanceWalked(){super("Distance Walked","HUD",6,760);} public void render(){Gfx.hud(x,y,String.format("Walk %.1f",mc.thePlayer.distanceWalkedModified));} }
    public static class PortalStatus extends Module { public PortalStatus(){super("Portal Status","HUD",6,780);} public void render(){Gfx.hud(x,y,mc.thePlayer.inPortal?"In Portal":"Portal: Off");} }
    public static class WeatherStatus extends Module { public WeatherStatus(){super("Weather Status","HUD",6,800);} public void render(){Gfx.hud(x,y,mc.theWorld.isRaining()?"Rain":"Clear");} }
    public static class RainStrengthHud extends Module { public RainStrengthHud(){super("Rain Strength","HUD",6,820);} public void render(){Gfx.hud(x,y,String.format("Rain %.0f%%",mc.theWorld.getRainStrength(1f)*100f));} }
    public static class PlayerCount extends Module { public PlayerCount(){super("Player Count","HUD",6,840);} public void render(){Gfx.hud(x,y,"Players "+mc.theWorld.playerEntities.size());} }
    public static class MobCount extends Module { public MobCount(){super("Mob Count","HUD",6,860);} public void render(){Gfx.hud(x,y,"Entities "+mc.theWorld.loadedEntityList.size());} }
    public static class ServerAddress extends Module { public ServerAddress(){super("Server Address","HUD",6,880);} public void render(){String s=mc.getCurrentServerData()==null?"Singleplayer":mc.getCurrentServerData().serverIP;Gfx.hud(x,y,s); } }
    public static class ServerBrand extends Module { public ServerBrand(){super("Server Brand","HUD",6,900);} public void render(){String s=mc.thePlayer.getClientBrand();Gfx.hud(x,y,"Brand "+(s==null?"Unknown":s));} }
    public static class Memory extends Module { public Memory(){super("Memory Usage","HUD",6,920);} public void render(){Runtime r=Runtime.getRuntime();long u=(r.totalMemory()-r.freeMemory())/1048576L;Gfx.hud(x,y,"RAM "+u+" MB");} }
    public static class JavaVersion extends Module { public JavaVersion(){super("Java Version","HUD",6,940);} public void render(){Gfx.hud(x,y,"Java "+System.getProperty("java.version"));} }
    public static class RenderDistanceHud extends Module { public RenderDistanceHud(){super("Render Distance","HUD",6,960);} public void render(){Gfx.hud(x,y,"Render "+mc.gameSettings.renderDistanceChunks+" chunks");} }
    public static class GUISettings extends Module { public GUISettings(){super("GUI Settings","HUD",6,980);} public void render(){Gfx.hud(x,y,"GUI scale "+mc.gameSettings.guiScale); } }
    public static class Sensitivity extends Module { public Sensitivity(){super("Sensitivity","HUD",6,1000);} public void render(){Gfx.hud(x,y,String.format("Sensitivity %.2f",mc.gameSettings.mouseSensitivity));} }
    public static class FOVInfo extends Module { public FOVInfo(){super("FOV Info","HUD",6,1020);} public void render(){Gfx.hud(x,y,"FOV "+mc.gameSettings.fovSetting); } }
    public static class LanguageInfo extends Module { public LanguageInfo(){super("Language","HUD",6,1040);} public void render(){Gfx.hud(x,y,"Lang "+mc.gameSettings.language); } }
    public static class Clock24 extends Module { public Clock24(){super("24H Clock","HUD",6,1060);} public void render(){java.util.Calendar c=java.util.Calendar.getInstance();Gfx.hud(x,y,String.format("%02d:%02d:%02d",c.get(11),c.get(12),c.get(13)));} }
    public static class DateHud extends Module { public DateHud(){super("Date","HUD",6,1080);} public void render(){java.util.Calendar c=java.util.Calendar.getInstance();Gfx.hud(x,y,String.format("%04d-%02d-%02d",c.get(1),c.get(2)+1,c.get(5)));} }
    public static class HealthBar extends Module { public HealthBar(){super("Health Bar","HUD",6,1100);} public void render(){float hp=Math.max(0,mc.thePlayer.getHealth()),max=Math.max(1,mc.thePlayer.getMaxHealth());int w=100;Gfx.rrect(x,y,w,8,3,0xA0000000);Gfx.rrect(x,y,(int)(w*Math.min(1,hp/max)),8,3,Theme.accent2());} }
    public static class FoodBar extends Module { public FoodBar(){super("Food Bar","HUD",6,1115);} public void render(){int w=100;int food=mc.thePlayer.getFoodStats().getFoodLevel();Gfx.rrect(x,y,w,8,3,0xA0000000);Gfx.rrect(x,y,food*5,8,3,Theme.accent());} }
    public static class CrosshairGap extends Module { public CrosshairGap(){super("Crosshair Gap","Render",0,0);} public void render(){net.minecraft.client.gui.ScaledResolution s=new net.minecraft.client.gui.ScaledResolution(mc);int cx=s.getScaledWidth()/2,cy=s.getScaledHeight()/2;Gfx.rrect(cx-2,cy-2,cx+2,cy+2,2,Theme.accent());} }
    public static class NoHurtCam extends Module { public NoHurtCam(){super("No Hurt Camera","Render",0,0);} public void tick(){if(mc.thePlayer!=null)mc.thePlayer.hurtTime=0;} }
    public static class AutoJumpOff extends Module { public AutoJumpOff(){super("Auto Jump Off","Player",0,0);} public void onEnable(){mc.gameSettings.autoJump=false;} }
    public static class NoWeather extends Module { public NoWeather(){super("No Weather 2","Render",0,0);} public void tick(){if(mc.theWorld!=null)mc.theWorld.setRainStrength(0f);} }
    public static class ClearChat extends Module { public ClearChat(){super("Clear Chat","Utility",0,0);} public void onEnable(){if(mc.ingameGUI!=null)mc.ingameGUI.getChatGUI().clearChatMessages();on=false;} }
    public static class ScreenshotInfo extends Module { public ScreenshotInfo(){super("Screenshot Info","Utility",0,0);} public void render(){Gfx.hud(x,y,"Screenshot: F2");} }


    // ===== Luvia 2.2 extra 10 modules (47 total in the 2.2 expansion) =====
    public static class OnGroundStatus extends Module {
        public OnGroundStatus(){super("On Ground Status","HUD",150,560);}
        public void render(){Gfx.hud(x,y,mc.thePlayer.onGround?"On Ground":"Airborne");}
    }
    public static class SneakStatus extends Module {
        public SneakStatus(){super("Sneak Status","HUD",150,580);}
        public void render(){Gfx.hud(x,y,mc.thePlayer.isSneaking()?"Sneaking":"Standing");}
    }
    public static class SprintStatus extends Module {
        public SprintStatus(){super("Sprint Status","HUD",150,600);}
        public void render(){Gfx.hud(x,y,mc.thePlayer.isSprinting()?"Sprinting":"Walking");}
    }
    public static class SelectedSlot extends Module {
        public SelectedSlot(){super("Selected Slot","HUD",150,620);}
        public void render(){Gfx.hud(x,y,"Slot "+(mc.thePlayer.inventory.currentItem+1)+"/9");}
    }
    public static class HorizontalVelocity extends Module {
        public HorizontalVelocity(){super("Horizontal Velocity","HUD",150,640);}
        public void render(){double v=Math.sqrt(mc.thePlayer.motionX*mc.thePlayer.motionX+mc.thePlayer.motionZ*mc.thePlayer.motionZ);Gfx.hud(x,y,String.format("H-Vel %.3f",v));}
    }
    public static class VerticalVelocity extends Module {
        public VerticalVelocity(){super("Vertical Velocity","HUD",150,660);}
        public void render(){Gfx.hud(x,y,String.format("V-Vel %.3f",mc.thePlayer.motionY));}
    }
    public static class UnderwaterStatus extends Module {
        public UnderwaterStatus(){super("Underwater Status","HUD",150,680);}
        public void render(){Gfx.hud(x,y,mc.thePlayer.isInsideOfMaterial(net.minecraft.block.material.Material.water)?"Underwater":"Not Underwater");}
    }
    public static class DimensionInfo extends Module {
        public DimensionInfo(){super("Dimension","HUD",150,700);}
        public void render(){if(mc.theWorld!=null)Gfx.hud(x,y,"Dimension "+mc.theWorld.provider.getDimensionId());}
    }
    public static class DifficultyInfo extends Module {
        public DifficultyInfo(){super("Difficulty","HUD",150,720);}
        public void render(){if(mc.theWorld!=null)Gfx.hud(x,y,"Difficulty "+mc.theWorld.getDifficulty().getDifficultyResourceKey());}
    }
    public static class BiomeTemperature extends Module {
        public BiomeTemperature(){super("Biome Temperature","HUD",150,740);}
        public void render(){if(mc.theWorld!=null&&mc.thePlayer!=null){net.minecraft.util.BlockPos p=new net.minecraft.util.BlockPos(mc.thePlayer);float t=mc.theWorld.getBiomeGenForCoords(p).getFloatTemperature(p);Gfx.hud(x,y,String.format("Temp %.2f",t));}}
    }

}
