package dev.luvia;

public final class Theme {
    public static final String[] NAMES={
        "Amethyst","Ocean","Ruby","Emerald","Sunset","Ice","Midnight","Rose",
        "Lime","Cyber","Gold","Mono"
    };
    private static final int[][] COLORS={
        {0xFFA78BFA,0xFF7C3AED,0xFF1C1633,0xFF140F24},
        {0xFF67E8F9,0xFF0891B2,0xFF102B3A,0xFF071820},
        {0xFFFF6B81,0xFFE11D48,0xFF35131D,0xFF1E0A10},
        {0xFF6EE7B7,0xFF059669,0xFF103329,0xFF071F18},
        {0xFFFFB86B,0xFFF97316,0xFF3A2114,0xFF1F120A},
        {0xFFA5F3FC,0xFF38BDF8,0xFF153044,0xFF091923},
        {0xFFB8A9FF,0xFF4F46E5,0xFF1B1B3A,0xFF09091A},
        {0xFFFF9ED8,0xFFEC4899,0xFF35152B,0xFF1D0A17},
        {0xFFA3E635,0xFF65A30D,0xFF263314,0xFF111A08},
        {0xFF22D3EE,0xFF7C3AED,0xFF211A3D,0xFF090A18},
        {0xFFFDE68A,0xFFD97706,0xFF3A2A12,0xFF1E1608},
        {0xFFE5E7EB,0xFF6B7280,0xFF252525,0xFF111111}
    };
    public static int current=0;
    public static int accent(){return COLORS[current][0];}
    public static int accent2(){return COLORS[current][1];}
    public static int panel(){return COLORS[current][2];}
    public static int bg(){return COLORS[current][3];}
    public static void next(){current=(current+1)%NAMES.length;}
    public static void prev(){current=(current+NAMES.length-1)%NAMES.length;}
    private Theme(){}
}
