package dev.luvia;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public class Gfx {
    public static final int ACCENT = 0xFFA78BFA;
    public static final int ACCENT2 = 0xFF7C3AED;
    public static final int BG = 0xE6140F24;
    public static final int PANEL = 0xFF1C1633;
    public static final int OFF = 0xFF3A3354;

    public static void rrect(int x, int y, int w, int h, int r, int c) {
        if (w <= 0 || h <= 0) return;
        for (int i = 0; i < h; i++) {
            int d = i < r ? r - i : (i >= h - r ? i - (h - 1 - r) : 0), in = 0;
            if (d > 0) in = (int)(r - Math.sqrt(Math.max(0, r * r - d * d)));
            Gui.drawRect(x + in, y + i, x + w - in, y + i + 1, c);
        }
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int r = 0;
        for (int s = 0; s <= 24; s += 8) {
            int ca = (a >> s) & 255, cb = (b >> s) & 255;
            r |= ((int)(ca + (cb - ca) * t) & 255) << s;
        }
        return r;
    }

    public static void text(String s, int x, int y, int c) {
        Minecraft.getMinecraft().fontRendererObj.drawStringWithShadow(s, x, y, c);
    }

    public static int width(String s) {
        return Minecraft.getMinecraft().fontRendererObj.getStringWidth(s);
    }

    public static void center(String s, int cx, int y, int c) {
        text(s, cx - width(s) / 2, y, c);
    }

    public static void hud(int x, int y, String s) {
        int w = width(s) + 10;
        rrect(x, y, w, 16, 4, 0x90140F24);
        Gui.drawRect(x, y + 3, x + 2, y + 13, Theme.accent());
        text(s, x + 6, y + 4, 0xFFFFFFFF);
    }

    public static void outline(int x, int y, int w, int h, int c) {
        Gui.drawRect(x, y, x + w, y + 1, c);
        Gui.drawRect(x, y + h - 1, x + w, y + h, c);
        Gui.drawRect(x, y, x + 1, y + h, c);
        Gui.drawRect(x + w - 1, y, x + w, y + h, c);
    }

    public static void line(int x1, int y1, int x2, int y2, int c) {
        GlStateManager.disableTexture2D();
        GlStateManager.color((c >> 16 & 255) / 255f, (c >> 8 & 255) / 255f,
                (c & 255) / 255f, ((c >>> 24) & 255) / 255f);
        GL11.glBegin(GL11.GL_LINES);
        GL11.glVertex2f(x1, y1); GL11.glVertex2f(x2, y2);
        GL11.glEnd();
        GlStateManager.enableTexture2D();
    }

    public static ScaledResolution sr() {
        return new ScaledResolution(Minecraft.getMinecraft());
    }
}
