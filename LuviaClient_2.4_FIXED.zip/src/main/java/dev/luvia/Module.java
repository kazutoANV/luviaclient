package dev.luvia;

public abstract class Module {
    public final String name, cat;
    public boolean on;
    public int x, y;

    public Module(String n, String c, int x, int y) {
        name = n; cat = c; this.x = x; this.y = y;
    }

    public void toggle() {
        on = !on;
        if (on) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void tick() {}
    public void render() {}
}
