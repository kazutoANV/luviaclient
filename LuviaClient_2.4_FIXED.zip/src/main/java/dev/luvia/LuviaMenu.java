package dev.luvia;

import java.io.IOException;
import java.util.*;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Mouse;

public class LuviaMenu extends GuiScreen {
    static final String[] CATS={"HUD","Player","Render","PvP","Utility"};
    static final int W=520,H=330;
    int sel=0,scroll=0;
    Map<Module,Float> anim=new HashMap<Module,Float>();

    int px(){return width/2-W/2;} int py(){return height/2-H/2;}
    List<Module> list(){List<Module> l=new ArrayList<Module>();for(Module m:Luvia.modules)if(m.cat.equals(CATS[sel]))l.add(m);return l;}

    @Override public void drawScreen(int mx,int my,float pt){
        Gui.drawRect(0,0,width,height,0xA0000000);
        int x=px(),y=py();
        Gfx.rrect(x-2,y-2,W+4,H+4,13,Theme.accent2());
        Gfx.rrect(x,y,W,H,12,Theme.bg());
        Gfx.rrect(x+7,y+7,125,H-14,9,Theme.panel());
        Gfx.text("Luvia",x+19,y+16,0xFFFFFFFF); Gfx.text("CLIENT",x+64,y+16,Theme.accent());
        Gui.drawRect(x+18,y+32,x+112,y+33,0x88777777);

        for(int i=0;i<CATS.length;i++){
            int cy=y+44+i*36;
            boolean hov=mx>x+13&&mx<x+119&&my>cy&&my<cy+29;
            if(i==sel)Gfx.rrect(x+13,cy,106,29,7,Theme.accent2());
            else if(hov)Gfx.rrect(x+13,cy,106,29,7,0xFF292929);
            Gfx.text(CATS[i],x+27,cy+10,i==sel?0xFFFFFFFF:0xFFBEBEBE);
        }
        Gfx.rrect(x+13,y+H-55,106,27,7,0xFF222222);
        Gfx.center("THEME",x+66,y+H-46,Theme.accent());
        Gfx.text(Theme.NAMES[Theme.current],x+21,y+H-20,0xFFE0E0E0);

        Gfx.text(CATS[sel],x+146,y+15,0xFFFFFFFF);
        Gfx.text("Click modules  •  Scroll",x+146,y+31,0xFF888888);
        Gfx.rrect(x+W-142,y+10,124,25,7,0xFF202020);
        Gfx.text("Theme: "+Theme.NAMES[Theme.current],x+W-133,y+19,Theme.accent());

        List<Module> l=list(); int row=0;
        for(int i=scroll;i<l.size();i++,row++){
            Module m=l.get(i); int ry=y+53+row*36,rx=x+144,rw=W-158;
            if(ry>y+H-9)break;
            boolean hov=mx>rx&&mx<rx+rw&&my>ry&&my<ry+31;
            Gfx.rrect(rx,ry,rw,31,7,hov?0xFF2B2B2B:Theme.panel());
            Gfx.text(m.name,rx+11,ry+11,0xFFFFFFFF);
            Gfx.text(m.cat,rx+11,ry+21,0xFF777777);
            float a=anim.containsKey(m)?anim.get(m):(m.on?1f:0f);
            a+=(m.on?1f:0f-a)*0.25f;anim.put(m,a);
            int sx=rx+rw-41,sy=ry+9;
            Gfx.rrect(sx,sy,32,14,7,Gfx.mix(0xFF444444,Theme.accent2(),a));
            Gfx.rrect(sx+2+(int)(18*a),sy+2,10,10,5,0xFFFFFFFF);
        }
        super.drawScreen(mx,my,pt);
    }

    @Override protected void mouseClicked(int mx,int my,int b)throws IOException{
        int x=px(),y=py();
        for(int i=0;i<CATS.length;i++){
            int cy=y+44+i*36;
            if(mx>x+13&&mx<x+119&&my>cy&&my<cy+29){sel=i;scroll=0;return;}
        }
        if(mx>x+13&&mx<x+119&&my>y+H-55&&my<y+H-28){Theme.next();return;}
        if(mx>x+W-142&&mx<x+W-18&&my>y+10&&my<y+35){Theme.next();return;}
        List<Module> l=list();int row=0;
        for(int i=scroll;i<l.size();i++,row++){
            int ry=y+53+row*36,rx=x+144,rw=W-158;if(ry>y+H-9)break;
            if(mx>rx&&mx<rx+rw&&my>ry&&my<ry+31){l.get(i).toggle();return;}
        }
        super.mouseClicked(mx,my,b);
    }

    @Override public void handleMouseInput()throws IOException{
        super.handleMouseInput(); int d=Mouse.getEventDWheel();
        if(d!=0){int max=Math.max(0,list().size()-7);if(d<0)scroll=Math.min(max,scroll+1);else scroll=Math.max(0,scroll-1);}
    }
    @Override public boolean doesGuiPauseGame(){return false;}
}
