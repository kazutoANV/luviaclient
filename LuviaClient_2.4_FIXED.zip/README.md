# Luvia Client 2.3 — Forge 1.8.9

Luvia Client is a client-side Minecraft Forge 1.8.9 project.

## GitHub Actions build

The repository contains a workflow at `.github/workflows/build.yml`.
It uses Java 8, ForgeGradle 2.1 and Gradle 2.14.1, then creates the JAR in `build/libs/`.

### Recommended GitHub layout

Upload the contents of this project to the repository root so that `build.gradle` is directly in the root:

```text
build.gradle
src/main/java/...
src/main/resources/mcmod.info
.github/workflows/build.yml
```

Then open **Actions → Build Luvia Client → Run workflow**.

The generated JAR is published under the workflow's **Artifacts** section.
