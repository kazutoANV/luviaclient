package dev.luvia;

import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = "luvia", name = "Luvia Client", version = "2.3", clientSideOnly = true)
public class Luvia {
    public static final List<Module> modules = new ArrayList<Module>();
    public static Modules.Zoom zoom;

    private final KeyBinding menuKey =
        new KeyBinding("Luvia Menu", Keyboard.KEY_RSHIFT, "Luvia Client");

    @EventHandler
    public void init(FMLInitializationEvent e) {
        ClientRegistry.registerKeyBinding(menuKey);

        zoom = new Modules.Zoom();

        modules.addAll(Arrays.asList(
            new Modules.Fps(),
            new Modules.Cps(),
            new Modules.Coords(),
            new Modules.Keys(),
            new Modules.Armor(),
            new Modules.Health(),
            new Modules.Food(),
            new Modules.Ping(),
            new Modules.Speed(),
            new Modules.Direction(),
            new Modules.ArrayListHud(),

            new Modules.ToggleSprint(),
            new Modules.SprintIndicator(),
            new Modules.PotionHud(),
            new Modules.KeystrokesBig(),
            new Modules.ItemInfo(),

            new Modules.Fullbright(),
            zoom,
            new Modules.MotionBlur(),
            new Modules.Crosshair(),
            new Modules.TimeChanger(),
            new Modules.NoBob(),
            new Modules.ThirdPerson(),
            new Modules.FPSBoostVisual(),

            new Modules.AutoGG(),
            new Modules.ReachDisplay(),
            new Modules.ComboCounter(),
            new Modules.HitColor(),
            new Modules.TargetInfo(),
            new Modules.SessionInfo(),

            new Modules.FPSGraph(), new Modules.Clock(), new Modules.WorldTime(),
            new Modules.Biome(), new Modules.Velocity(), new Modules.JumpCounter(),
            new Modules.AirTime(), new Modules.Facing(), new Modules.ChunkCoords(),
            new Modules.LightLevel(), new Modules.EntityCount(), new Modules.Durability(),
            new Modules.PotionList(), new Modules.FPSLimit(), new Modules.SmoothCamera(),
            new Modules.NoWeather(), new Modules.NoParticles(), new Modules.NoClouds(),
            new Modules.LowGraphics(), new Modules.FastRender(), new Modules.HideHand(),
            new Modules.CleanParticles(), new Modules.CrosshairDot(), new Modules.HitMarker(),
            new Modules.CombatStatus(), new Modules.TargetDistance(), new Modules.AttackIndicator(),
            new Modules.FPSColor(), new Modules.ServerInfo(), new Modules.MemoryInfo(),
            new Modules.CoordinatesCopyHint(), new Modules.AutoRespawn(), new Modules.ClearEffects(),
            new Modules.HideGUI(),

            new Modules.Saturation(), new Modules.Experience(), new Modules.Level(),
            new Modules.Position(), new Modules.MotionX(), new Modules.MotionY(), new Modules.MotionZ(),
            new Modules.Rotation(), new Modules.Pitch(), new Modules.BlockUnder(), new Modules.BiomeCoords(),
            new Modules.FallDistance(), new Modules.JumpHeight(), new Modules.DistanceWalked(),
            new Modules.PortalStatus(), new Modules.WeatherStatus(), new Modules.RainStrengthHud(),
            new Modules.PlayerCount(), new Modules.MobCount(), new Modules.ServerAddress(), new Modules.ServerBrand(),
            new Modules.Memory(), new Modules.JavaVersion(), new Modules.RenderDistanceHud(), new Modules.GUISettings(),
            new Modules.Sensitivity(), new Modules.FOVInfo(), new Modules.LanguageInfo(), new Modules.Clock24(),
            new Modules.DateHud(), new Modules.HealthBar(), new Modules.FoodBar(), new Modules.CrosshairGap(),
            new Modules.NoHurtCam(), new Modules.AutoJumpOff(), new Modules.ClearChat(),
            new Modules.ScreenshotInfo(),
            new Modules.OnGroundStatus(), new Modules.SneakStatus(), new Modules.SprintStatus(),
            new Modules.SelectedSlot(), new Modules.HorizontalVelocity(), new Modules.VerticalVelocity(),
            new Modules.UnderwaterStatus(), new Modules.DimensionInfo(), new Modules.DifficultyInfo(),
            new Modules.BiomeTemperature()
        ));

        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void key(InputEvent.KeyInputEvent e) {
        if (menuKey.isPressed()) Minecraft.getMinecraft().displayGuiScreen(new LuviaMenu());
    }

    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || Minecraft.getMinecraft().thePlayer == null) return;
        for (Module m : modules) if (m.on) m.tick();
    }

    @SubscribeEvent
    public void hud(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL ||
            Minecraft.getMinecraft().thePlayer == null) return;
        for (Module m : modules) if (m.on) m.render();
    }

    @SubscribeEvent
    public void worldRender(RenderWorldLastEvent e) {
        for (Module m : modules) {
            if (m.on && m instanceof Modules.MotionBlur) {
                ((Modules.MotionBlur)m).renderBlur();
            }
        }
    }

    @SubscribeEvent
    public void fov(FOVUpdateEvent e) {
        if (zoom != null && zoom.active()) e.newfov = e.fov / 4f;
    }

    @SubscribeEvent
    public void initGui(GuiScreenEvent.InitGuiEvent.Post e) {
        if (e.gui instanceof GuiMainMenu || e.gui instanceof GuiIngameMenu) {
            e.buttonList.add(new GuiButton(9999, 4, 4, 78, 20, "\u00a7dLuvia"));
            e.buttonList.add(new GuiButton(9998, 86, 4, 108, 20, "Theme: "+Theme.NAMES[Theme.current]));
        }
    }

    @SubscribeEvent
    public void action(GuiScreenEvent.ActionPerformedEvent.Post e) {
        if (e.button != null && e.button.id == 9999)
            Minecraft.getMinecraft().displayGuiScreen(new LuviaMenu());
        if (e.button != null && e.button.id == 9998) {
            Theme.next();
            e.button.displayString = "Theme: "+Theme.NAMES[Theme.current];
        }
    }
}
